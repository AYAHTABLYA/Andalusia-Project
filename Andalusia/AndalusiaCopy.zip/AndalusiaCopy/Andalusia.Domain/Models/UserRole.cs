﻿namespace AndalusiaApp.Models;

public class UserRole
{
    public long UserId { get; set; }
    public int RoleId { get; set; }
    public User User { get; set; } = null!;
    public Role Role { get; set; } = null!;
}