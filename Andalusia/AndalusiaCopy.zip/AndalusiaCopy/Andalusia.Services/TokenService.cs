using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Andalusia.Shared.Authorization;
using AndalusiaApp.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace AndalusiaApp.Services;

public class TokenService(IConfiguration config) : ITokenService
{
    public (string Token, DateTime ExpiresAt) GenerateToken(User user, string roleName, IEnumerable<string> permissions)
    {
        var secretKey = config["Jwt:Key"] ?? "AndalusiaSuperSecretKey2026SecureKeyWith32CharsMinimum!";
        var issuer = config["Jwt:Issuer"] ?? "AndalusiaApp";
        var audience = config["Jwt:Audience"] ?? "AndalusiaClients";
        var expiresAt = DateTime.UtcNow.AddDays(7);

        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.UserId.ToString()),
            new("sub", user.UserId.ToString()),
            new(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            new(ClaimTypes.Email, user.Email),
            new(ClaimTypes.Name, $"{user.FirstName} {user.LastName}".Trim()),
            new(ClaimTypes.Role, roleName)
        };

        // One claim per permission: policies use RequireClaim("permission", code).
        claims.AddRange(permissions
            .Distinct()
            .Select(p => new Claim(AppClaimTypes.Permission, p)));

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secretKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var tokenDescriptor = new SecurityTokenDescriptor
        {
            Subject = new ClaimsIdentity(claims),
            Expires = expiresAt,
            Issuer = issuer,
            Audience = audience,
            SigningCredentials = creds
        };

        var handler = new JwtSecurityTokenHandler();
        var token = handler.CreateToken(tokenDescriptor);

        return (handler.WriteToken(token), expiresAt);
    }
}
