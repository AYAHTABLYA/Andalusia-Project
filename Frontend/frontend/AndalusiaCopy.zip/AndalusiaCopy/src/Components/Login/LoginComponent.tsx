import { memo, useState } from "react";
import type { ChangeEvent, FormEvent } from "react";
import { Link } from "react-router-dom";
import type { loginFormType } from "../../Types/LoginFormType";
import type { SubmitStatus } from "../../Types/SubmitStatus";
import "./style.css";

function LoginComponent({
  status,
  formData,
  handleChange,
  handleSubmit,
}: {
  status: SubmitStatus;
  formData: loginFormType;
  handleChange: (e: ChangeEvent<HTMLInputElement>) => void;
  handleSubmit: (e: FormEvent) => void;
}) {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="login_form_component">
      <div className="login_intro">
        <h2>Log in</h2>
        <p>Sign in to your account</p>
      </div>

      {status === "loading" && (
        <div className="notice">
          <span className="spinner" />
          Signing you in...
        </div>
      )}
      {status === "success" && (
        <div className="notice success">
          <span className="material-symbols-outlined">check_circle</span>
          Signed in successfully.
        </div>
      )}

      <form className="login_form" onSubmit={handleSubmit}>
        <div className="field">
          <label htmlFor="email">Email</label>
          <div className="input_wrap">
            <span className="material-symbols-outlined">mail</span>
            <input
              id="email"
              className="input"
              name="email"
              type="email"
              required
              placeholder="name@andalusia-academy.edu.eg"
              value={formData.email}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="field">
          <div className="login_password_row">
            <label htmlFor="password">Password</label>
            <a href="#forgot">Forgot password?</a>
          </div>
          <div className="input_wrap">
            <span className="material-symbols-outlined">lock</span>
            <input
              id="password"
              className="input"
              name="password"
              type={showPassword ? "text" : "password"}
              required
              placeholder="Enter your password"
              value={formData.password}
              onChange={handleChange}
            />
            <button
              type="button"
              aria-label={showPassword ? "Hide password" : "Show password"}
              onClick={() => setShowPassword((s) => !s)}
            >
              <span className="material-symbols-outlined">
                {showPassword ? "visibility_off" : "visibility"}
              </span>
            </button>
          </div>
        </div>

        <button className="btn" type="submit" disabled={status === "loading"}>
          Log in
        </button>
      </form>

      <p className="login_footer">
        New learner? <Link to="/register">Create an account</Link>
      </p>
    </div>
  );
}

export default memo(LoginComponent);
