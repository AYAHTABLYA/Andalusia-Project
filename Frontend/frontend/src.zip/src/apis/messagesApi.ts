import { apiGet, apiPost } from "./academyApi";
import type { ChatMessage, MessageContact } from "../Types/Messages";

// People the signed-in user may message (a learner's instructors / an instructor's learners).
export const getMessageContacts = (signal?: AbortSignal) =>
  apiGet<MessageContact[]>("/api/messages/contacts", undefined, signal);

// The whole thread with one contact (the server marks their messages as read).
export const getMessageThread = (userId: number, signal?: AbortSignal) =>
  apiGet<ChatMessage[]>(`/api/messages/with/${userId}`, undefined, signal);

export const sendDirectMessage = (recipientId: number, body: string) =>
  apiPost<ChatMessage>("/api/messages", { recipientId, body });
