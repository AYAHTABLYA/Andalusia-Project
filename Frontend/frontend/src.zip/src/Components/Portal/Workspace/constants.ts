type WorkspaceLink = {
  to: string;
  label: string;
  icon: string;
  end?: boolean;
};

// Order = order in the workspace sidebar.
const WORKSPACE_LINKS: WorkspaceLink[] = [
  { to: "/workspace", label: "Overview", icon: "grid_view", end: true },
  { to: "/workspace/courses", label: "My courses", icon: "menu_book" },
  { to: "/workspace/schedule", label: "My schedule", icon: "calendar_month" },
  { to: "/workspace/assignments", label: "Assignments", icon: "assignment_turned_in" },
  { to: "/workspace/materials", label: "Materials", icon: "folder_open" },
  { to: "/workspace/messages", label: "Messages", icon: "forum" },
];

// Sort weight of each assignment status: unfinished first, graded last.
const ASSIGNMENT_ORDER = { Pending: 0, Submitted: 1, Graded: 2 } as const;

export type { WorkspaceLink };
export { WORKSPACE_LINKS, ASSIGNMENT_ORDER };
