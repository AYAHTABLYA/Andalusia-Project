import React, { useState } from "react";
import { RiCustomerService2Fill } from "react-icons/ri";
import { IoClose } from "react-icons/io5";
import botData from "../../data/botData.json";
import "./CustomerServiceBot.css";

const CustomerServiceBot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTopic, setSelectedTopic] = useState(null);
  const [selectedQuestion, setSelectedQuestion] = useState(null);

  const handleWhatsAppRedirect = () => {
    const { whatsappNumber, defaultMessage } = botData.contactUs;
    const encodedMessage = encodeURIComponent(defaultMessage);
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodedMessage}`;
    window.open(whatsappUrl, "_blank");
  };

  const handleTopicSelect = (topic) => {
    setSelectedTopic(topic);
    setSelectedQuestion(null);
  };

  const resetSelection = () => {
    setSelectedTopic(null);
    setSelectedQuestion(null);
  };

  return (
    <div className="bot-wrapper">
      {/* زر الفتح والإغلاق باستخدام الأيقونات */}
      <button
        className="bot-toggle-btn"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="فتح شات خدمة العملاء"
      >
        {isOpen ? <IoClose size={26} /> : <RiCustomerService2Fill size={28} />}
      </button>

      {isOpen && (
        <div className="bot-container">
          <div className="bot-header">
            <h4>مركز مساعدة الأكاديمية</h4>
            <button className="bot-close-btn" onClick={() => setIsOpen(false)}>
              <IoClose size={20} />
            </button>
          </div>

          <div className="bot-body">
            <p className="bot-welcome">{botData.welcomeMessage}</p>

            {selectedTopic && (
              <button className="bot-back-btn" onClick={resetSelection}>
                ← العودة إلى قائمة الموضوعات
              </button>
            )}

            <div className="bot-questions-list">
              {/* عرض الموضوعات بألوان الهوية */}
              {!selectedTopic &&
                botData.topics.map((topic) => (
                  <button
                    key={topic.id}
                    className="bot-topic-btn"
                    style={{ "--accent-color": topic.badgeColor }}
                    onClick={() => handleTopicSelect(topic)}
                  >
                    <span
                      className="topic-indicator"
                      style={{ backgroundColor: topic.badgeColor }}
                    ></span>
                    {topic.title}
                  </button>
                ))}

              {/* عرض أسئلة الموضوع المحدد */}
              {selectedTopic &&
                selectedTopic.questions.map((q) => (
                  <button
                    key={q.id}
                    className={`bot-q-btn ${selectedQuestion?.id === q.id ? "active" : ""}`}
                    onClick={() => setSelectedQuestion(q)}
                  >
                    {q.question}
                  </button>
                ))}

              <button
                className="bot-whatsapp-btn"
                onClick={handleWhatsAppRedirect}
              >
                {botData.contactUs.label}
              </button>
            </div>

            {/* عرض الإجابة والنقاط والعنصر البصري (Visualization) */}
            {selectedQuestion && (
              <div className="bot-answer-box">
                {selectedQuestion.answerPoints && (
                  <ul className="bot-points-list">
                    {selectedQuestion.answerPoints.map((point, index) => (
                      <li key={index}>{point}</li>
                    ))}
                  </ul>
                )}

                {/* المكون البصري للخطوات (Stepper Visualization) */}
                {selectedQuestion.visualization && (
                  <div className="bot-visualization-stepper">
                    {selectedQuestion.visualization.steps.map((item, index) => (
                      <div className="viz-step-item" key={index}>
                        <div
                          className="viz-step-num"
                          style={{
                            backgroundColor:
                              selectedTopic?.badgeColor || "#007bff",
                          }}
                        >
                          {item.step}
                        </div>
                        <div className="viz-step-title">{item.title}</div>
                      </div>
                    ))}
                  </div>
                )}

                {selectedQuestion.topicUrl && (
                  <a
                    href={selectedQuestion.topicUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bot-topic-link"
                  >
                    انتقل للصفحة للتفاصيل الكاملة ←
                  </a>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerServiceBot;
