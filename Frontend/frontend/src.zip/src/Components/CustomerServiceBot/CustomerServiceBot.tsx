import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { RiCustomerService2Fill } from "react-icons/ri";
import { IoClose } from "react-icons/io5";
import rawBotData from "../../data/botData.json";
import type { BotData, BotQuestion, BotTopic } from "../../Types/Bot";
import "./CustomerServiceBot.css";

const botData = rawBotData as BotData;

function CustomerServiceBot() {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);
  const [topic, setTopic] = useState<BotTopic | null>(null);
  const [question, setQuestion] = useState<BotQuestion | null>(null);
  const answerRef = useRef<HTMLDivElement>(null);

  // Close with Escape
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setIsOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [isOpen]);

  // Bring the answer into view when a question is picked
  useEffect(() => {
    if (question) answerRef.current?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [question]);

  const openWhatsApp = () => {
    const { whatsappNumber, defaultMessage } = botData.contactUs;
    window.open(
      `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(defaultMessage)}`,
      "_blank",
      "noopener,noreferrer",
    );
  };

  const pickTopic = (t: BotTopic) => {
    setTopic(t);
    setQuestion(null);
  };

  const backToTopics = () => {
    setTopic(null);
    setQuestion(null);
  };

  const goTo = (path: string) => {
    if (/^https?:\/\//i.test(path)) {
      window.open(path, "_blank", "noopener,noreferrer");
    } else {
      navigate(path);
      setIsOpen(false);
    }
  };

  return (
    <div className="bot-wrapper" dir="rtl">
      {isOpen && (
        <div className="bot-container" role="dialog" aria-label={botData.title}>
          <div className="bot-header">
            <h4>{botData.title}</h4>
            <button type="button" className="bot-close-btn" onClick={() => setIsOpen(false)} aria-label="إغلاق">
              <IoClose size={20} />
            </button>
          </div>

          <div className="bot-body">
            <p className="bot-welcome">{botData.welcomeMessage}</p>

            {topic && (
              <button type="button" className="bot-back-btn" onClick={backToTopics}>
                → العودة إلى الموضوعات
              </button>
            )}

            <div className="bot-questions-list">
              {!topic &&
                botData.topics.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className="bot-topic-btn"
                    style={{ "--accent-color": t.badgeColor } as React.CSSProperties}
                    onClick={() => pickTopic(t)}
                  >
                    <span className="topic-indicator" style={{ backgroundColor: t.badgeColor }} />
                    {t.title}
                  </button>
                ))}

              {topic &&
                topic.questions.map((q) => (
                  <button
                    key={q.id}
                    type="button"
                    className={`bot-q-btn ${question?.id === q.id ? "active" : ""}`}
                    onClick={() => setQuestion(q)}
                  >
                    {q.question}
                  </button>
                ))}
            </div>

            {question && (
              <div className="bot-answer-box" ref={answerRef}>
                <ul className="bot-points-list">
                  {question.answerPoints.map((p, i) => (
                    <li key={i}>{p}</li>
                  ))}
                </ul>

                {question.visualization && (
                  <div className="bot-visualization-stepper">
                    {question.visualization.steps.map((s, i) => (
                      <div className="viz-step-item" key={i}>
                        <div className="viz-step-num" style={{ backgroundColor: topic?.badgeColor }}>
                          {s.step}
                        </div>
                        <div className="viz-step-title">{s.title}</div>
                      </div>
                    ))}
                  </div>
                )}

                {question.topicPath && (
                  <button type="button" className="bot-topic-link" onClick={() => goTo(question.topicPath!)}>
                    {question.topicLabel ?? "انتقل للصفحة للتفاصيل"} ←
                  </button>
                )}
              </div>
            )}
          </div>

          <div className="bot-footer">
            <button type="button" className="bot-whatsapp-btn" onClick={openWhatsApp}>
              {botData.contactUs.label}
            </button>
          </div>
        </div>
      )}

      <button
        type="button"
        className="bot-toggle-btn"
        onClick={() => setIsOpen((o) => !o)}
        aria-label={isOpen ? "إغلاق خدمة العملاء" : "فتح خدمة العملاء"}
        aria-expanded={isOpen}
      >
        {isOpen ? <IoClose size={26} /> : <RiCustomerService2Fill size={28} />}
      </button>
    </div>
  );
}

export default CustomerServiceBot;
